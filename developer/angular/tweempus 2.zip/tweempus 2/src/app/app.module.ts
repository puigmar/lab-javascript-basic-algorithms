import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';

import { CoreModule } from '../app/core/core.module';

import { DashboardModule } from './dashboard/dashboard.module';
import { UnderlineDirective } from './directives/underline-text.directive';

@NgModule({
  declarations: [
    AppComponent,
    UnderlineDirective
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    CoreModule,
    DashboardModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
