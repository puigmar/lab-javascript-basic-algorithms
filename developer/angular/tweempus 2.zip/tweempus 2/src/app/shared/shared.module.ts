import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { TwimpCardComponent } from './twimp/twimp-card/twimp-card.component';
import { TwempusTwimpListComponent } from './twimp/twimp-list/twimp-list.component';



@NgModule({
  declarations: [TwimpCardComponent, TwempusTwimpListComponent],
  imports: [
    CommonModule
  ],
  exports: [
    TwimpCardComponent,
    TwempusTwimpListComponent
  ]
})
export class SharedModule { }
