import { Component, Input, OnInit } from '@angular/core';

import { TwimpCardComponent} from '../twimp-card/twimp-card.component';

import { Author } from '../../author/author.model';
import { Twimp } from '../twimp.model';

@Component({
  selector: 'twempus-twimp-list',
  templateUrl: './twimp-list.component.html',
  styleUrls: ['./twimp-list.component.scss']
})

export class TwempusTwimpListComponent implements OnInit {

  authors: Author[] = [];
  twimps: Twimp[] = [];
  text = 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aliquam efficitur sodales libero, sit amet posuere arcu consectetur ut. Nam volutpat ligula ac nunc consectetur vestibulum.'

  ngOnInit(){
    this.authors.push(new Author('1'));
    this.twimps.push(new Twimp('1', '', this.authors[0], this.text, '01/01/2020'));
    this.twimps.push(new Twimp('2', '', this.authors[0], this.text, '01/01/2020'));
    this.twimps.push(new Twimp('3', '', this.authors[0], this.text, '01/01/2020'));
    this.twimps.push(new Twimp('4', '', this.authors[0], this.text, '01/01/2020'));
  }


}
