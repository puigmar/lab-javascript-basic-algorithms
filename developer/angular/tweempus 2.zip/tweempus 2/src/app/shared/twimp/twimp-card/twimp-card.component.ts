import { Component, Input } from '@angular/core';

import { Twimp } from '../twimp.model';

@Component({
  selector: 'tweempus-twimp-card',
  templateUrl: './twimp-card.component.html',
  styleUrls: ['./twimp-card.component.scss']
})

export class TwimpCardComponent{

  @Input() twimp:Twimp;

  updateFavourite(): void{
    this.twimp.favorite = !this.twimp.favorite;
  }

  configClass(){
    let params = {
      'fav_icon-selected': this.twimp.favorite
    }
    return params;
  }

}
