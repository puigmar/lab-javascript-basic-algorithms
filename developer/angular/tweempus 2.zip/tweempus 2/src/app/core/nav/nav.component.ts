import { Component } from '@angular/core';

@Component({
  selector: 'tweempus-nav',
  templateUrl: './nav.component.html',
  styleUrls: ['./nav.component.scss']
})
export class NavComponent {

}
