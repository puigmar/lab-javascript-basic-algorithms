import { Component } from '@angular/core';

@Component({
  selector: 'tweempus-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss']
})
export class AppComponent {
  title = 'tweempus';
}
